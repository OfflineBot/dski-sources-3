package de.dhbw.greeting.service;

import java.util.Arrays;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
@Profile("prod")
public class GreetingServiceProdImpl implements GreetingService {
    @Value("${greeting.text:Hallo}")
    private String text;

    @Value("${greeting.allowed-names}")
    private String[] allowedNames;

    @Override
    public String greet(String name) {
        if (!Arrays.asList(allowedNames).contains(name)) {
            return "Name steht nicht auf der Gästeliste";
        }
        return text + " " + name;
    }
}
