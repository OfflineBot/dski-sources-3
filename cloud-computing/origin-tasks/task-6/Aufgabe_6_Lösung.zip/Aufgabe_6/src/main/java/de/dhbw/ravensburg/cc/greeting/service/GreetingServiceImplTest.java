package de.dhbw.ravensburg.cc.greeting.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("test")
public class GreetingServiceImplTest implements GreetingService {

    public String getGreeting(){
        //Für "test" Profil bitte englische Übersetzung zurückgeben:
        return "Welcome to the course on cloud computing";
    }

}
