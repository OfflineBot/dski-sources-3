package de.dhbw.ravensburg.cc.greeting.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("dev")
public class GreetingServiceImpl implements GreetingService {

    public String getGreeting(){
        //Für "dev" Profil bitte französische Übersetzung zurückgeben:
        return "Bienvenue au cours sur le cloud computing";
    }
}
