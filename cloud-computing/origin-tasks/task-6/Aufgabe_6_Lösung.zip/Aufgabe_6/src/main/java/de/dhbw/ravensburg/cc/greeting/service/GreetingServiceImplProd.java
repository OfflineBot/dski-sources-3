package de.dhbw.ravensburg.cc.greeting.service;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("prod")
public class GreetingServiceImplProd implements GreetingService {

    public String getGreeting(){
        //Für "prod" Profil bitte deutsche Übersetzung zurückgeben:
        return "Herzlich Willkommen zur Veranstaltung Cloud Computing";

    }

}
